import { UploadFileComponent } from './upload-file/upload-file.component';

export const components = [UploadFileComponent];

export * from './upload-file/upload-file.component';
