import { UploadComponent } from './upload/upload.component';

export const containers = [UploadComponent];

export * from './upload/upload.component';
